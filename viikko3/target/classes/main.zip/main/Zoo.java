// Tekijä: Sami Anttalainen
// Päivämäärä: 1.2.2023
// Opiskelijanumero: 001067291
// Tehtävä: Eläintarha


package main;


public class Zoo {
    String zooName;


    public Zoo(String zooName) {
        this.zooName = zooName;
    }
    
}
